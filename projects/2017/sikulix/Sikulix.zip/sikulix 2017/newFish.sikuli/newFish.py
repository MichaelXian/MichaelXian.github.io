import random
def gaus(u):
    x = random.gauss(0,u)
    if( x <= -1.5*u):
        x = -0.123*u
    else: 
        if (x >= 1.5*u):
            x = 0.351*u
        
    return x

#aRegion = Region(462,64,543,466)
aRegion = Region(889,488,142,144)
#aImage = Pattern("small target.png").similar(0.50)
aImage = "newtarget.png"

while True:
    aRegion.wait(aImage, 600)
#    sleep(0.1+gaus(0.05))
    sleep(0.1)
    keyDown("e")
#   sleep(0.15+gaus(0.025))
    sleep(0.101)
    keyUp("e")
#   sleep(3.25+gaus(0.12))
    sleep(3)
    keyDown("5")
#    sleep(0.15+gaus(0.025))
    sleep(0.101)
    keyUp("5")
#    sleep(4.25+gaus(0.22))
    sleep(3)
    keyDown("e")
#    sleep(0.15+gaus(0.025))
    sleep(0.101)
    keyUp("e")




