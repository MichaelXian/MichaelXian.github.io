import random
def gauss(u):
    x = random.gauss(u)
    if( x <= -2*u):
        x = -0.123*u
    else: 
        if (x >= 1.5*u):
            x = 0.351*u
        
    return x

while True:
    aRegion = Region(598,270,997,718)
    #aImage = Pattern("hook1-1.png").similar(0.50)        
    aImage = "hook2.png"
    wait(aImage, 60) 
    sleep(0.3+gaus(0.1))
    keyDown("e")
    sleep(0.1+gaus(0.05))
    keyUp("e")
    sleep(1.071+gaus(0.2))
    keyDown("e")
    sleep(0.1+gaus(0.05))
    keyUp("e")




