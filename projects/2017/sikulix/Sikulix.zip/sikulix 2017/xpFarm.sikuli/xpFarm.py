import random
def gaus(u):
    x = random.gauss(0,u)
    if( x <= u):
        x = -0.123*u
    else: 
        if (x >= u):
            x = 0.351*u
        
    return x

def press(a,x):
    keyDown(a)
    sleep(x + gaus(x/4))
    keyUp(a)
   
while True:
    sleep(3 + gaus(3))
    press("3",0.2)
    #sleep(1 + gaus(1))
    #x = (1 + gaus(1))
    #press("a",x)
    #sleep(0.5 + gaus(0.5))
    #press("d",x) 