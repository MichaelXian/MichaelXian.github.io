trick = "trick.png"
trick2 = "trick2-1.png" 
trickRegion = Region(496,309,281,209)
x1 = "x1.png"
x2 = "x2.png" 
xRegion = Region(786,41,64,53)
x3 = "x3.png"
xRegion2 = Region(768,69,72,64)
confirm = "confirm.png"
confirmRegion = Region(510,329,248,147)
start = "start-1.png"
startRegion = Region(441,97,59,66)
sleep(5)
while True:
    try:
        if trickRegion.exists(trick):
            trickRegion.doubleClick(trick)
        if trickRegion.exists(trick2):
            trickRegion.doubleClick(trick2)
        if xRegion.exists(x1):
            xRegion.doubleClick(x1)
        if xRegion.exists(x2):
            xRegion.doubleClick(x2)
        if xRegion2.exists(x3):
            xRegion2.doubleClick(x3)
        if confirmRegion.exists(confirm):
            confirmRegion.doubleClick(confirm)
        if startRegion.exists(start):
            startRegion.doubleClick(start)
        sleep(0.01)
    except:
        sleep(0.01)




