import random
def gaus(u):
    x = random.gauss(0,u)
    if( x <= 0):
        x = gaus(u)
    else: 
        if (x >= 1.5*u):
            x = gaus(u)
    return x

while True:
    type("f")
    sleep(gaus(5))

    