def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.2)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

appleRegion = Region(0,0,50,50)
appleImage = Pattern("Screen Shot 2017-07-31 at 12.01.04 PM.png").exact()
iconRegion = Region(50,1000,1800,80)
icon = Pattern("icon3.png").exact()
loginRegion = Region(504,490,203,105)
login = "login.png"
playRegion = Region(1650,1000,200,80)

play = "play.png"
settingsRegion = Region(0,0,30,30)
settings = "settings.png"
exitRegion = Region(870,600,50,50)
exitToDesktop = "exitToDesktop.png"
errorRegion = Region(698,196,548,276)
errorImage = "error.png"
okRegion = Region(1022,339,185,92)
okImage = "OK.png"
while True:
    
    while appleRegion.exists(appleImage):
        sleep(1)
        hover(Location(1440,1079))
        sleep(1)
        Click(iconRegion,icon)        
        Click(loginRegion,login)
        if errorRegion.exists(errorImage):
            Click(okRegion,okImage)
    while appleRegion.exists(appleImage) == None:    
        sleep(1)
        Click(playRegion,play)
        Click(playRegion,play)
        Click(settingsRegion,settings)
        Click(playRegion,play)
        Click(playRegion,play)
        Click(exitRegion,exitToDesktop)
        Click(playRegion,play)
        Click(playRegion,play)
        hover(Location(0,0))
    sleep(86400)
        