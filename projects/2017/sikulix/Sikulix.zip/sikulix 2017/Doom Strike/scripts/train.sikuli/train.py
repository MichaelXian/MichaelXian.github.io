def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.2)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)
 
setAutoWaitTimeout(0)
buildingR = Region(131,318,151,151)
city ="city centre.png"
menuR = Region(311,277,96,69)
trainR = Region(208,665,171,64)
trainM = "train-menu.png"
trainB = "train-button.png"
trainBG = "train-button-greyed.png"
while True:
    Click(buildingR,city)
    Click(menuR,trainM)
    Click(trainR,trainB)
#        Click(trainR,trainBG)
