def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.4)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

screen = Region(390,46,372,625)
city = "hanseatic.png"
deploy = "deploy.png"

origin = "san francisco.png"
deployR = Region(595,623,152,35)
deployConfirm ="deploy2.png"
back = "return.png"
#x = 0
while True:
    Click(screen,city)
    Click(screen,deploy)
    Click(screen,origin)
    Click(deployR,deployConfirm)
    sleep(5)
#    while x < 5:
    Click(screen,back)
#        x = x + 1