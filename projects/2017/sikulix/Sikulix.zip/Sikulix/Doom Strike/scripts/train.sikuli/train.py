def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.2)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

setAutoWaitTimeout(0.1)
buildingR = Region(486,222,266,248)
city = "city centre.png"
trainR = Region(611,613,76,29)
trainM = "train-menu.png"
trainB = "train-button.png"
trainBG = "train-button-greyed.png"
#costR = Region(399,469,182,170)
#silicon = "silicon.png"
nextR = Region(704,389,58,71)
nextI = "next.png"
while True:
    Click(buildingR,city)
    Click(buildingR,trainM)
#    if costR.exists(silicon):
    sleep(1)
#    if costR.exists(silicon):
    Click(trainR,trainB)
#    else:
#        Click(nextR,nextI)

