def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.4)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

setAutoWaitTimeout(0.5)
buildingR = Region(393,66,364,487)
#buildingR = Region(0,120,342,429)
building = Pattern("manufactory.png").similar(0.50)
menuR = Region(676,242,73,73)
destr = "destroy.png"
demoR = Region(588,574,173,57)
demo = "demolish.png"
empty = "empty3.png"
buildR = Region(640,609,69,29)
#buildR = Region(155,596,220,70)

build = "build.png"
build2 = "build2.png"
speed = "speed.png"
sleep(1)
while True:
#        Click(buildingR,building)
#        Click(buildingR,destr)
#        Click(demoR,demo)
        Click(buildingR,empty)
        Click(buildingR,build)
        Click(buildR,build2)
#        sleep(2)
        if menuR.exists(speed):
            sleep(5)
            Click(menuR,speed)