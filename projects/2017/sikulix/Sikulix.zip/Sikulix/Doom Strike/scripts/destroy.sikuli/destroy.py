def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.4)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

setAutoWaitTimeout(0.5)
buildingR = Region(388,45,371,622)
#buildingR = Region(0,120,342,429)
building = "food.png"
menuR = Region(676,242,73,73)
destr = "destroy.png"
demoR = Region(588,574,173,57)
#demoR = Region(182,561,205,84)
demo = "demolish.png"
empty = "empty.png"
buildR = Region(640,609,69,29)
build = "build.png"
build2 = "build2.png"
speed = "speed.png"
sleep(1)
while True:
        Click(buildingR,building)
        sleep(0.2)
        Click(buildingR,destr)
        Click(demoR,demo)
        sleep(0.6)
#        Click(buildingR,empty)
#        Click(menuR,build)
#        Click(buildR,build2)
#        sleep(2)
#        if menuR.exists(speed):
#            sleep(5)
#            Click(menuR,speed)