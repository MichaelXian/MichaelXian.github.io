closeAd = Region(686,116,58,50)
raid = "raid.png"
raidR = Region(541,228,64,23)
oil = Location(700,350)
locations = [Location(550,263),Location(598,269),Location(563,344),Location(593,343),Location(550,450),Location(587,487)]
def Click(loc):
    try:
        hover(loc)
        mouseDown(Button.LEFT)
        sleep(0.1)
        mouseUp(Button.LEFT) 
    except:
        sleep(0.001)

def qC(reps):
    for i  in list(range(reps)):
        try:        
            mouseDown(Button.LEFT)
            sleep(0.001)
            mouseUp(Button.LEFT) 
        except:
            sleep(0.001)
                    
sleep(1)

while True:
    for l in locations:
        hover(l)
        qC(10)
