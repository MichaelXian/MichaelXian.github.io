def Click(reg,img):
    try:
        reg.hover(img)
        mouseDown(Button.LEFT)
        sleep(0.4)
        mouseUp(Button.LEFT)
    except:
        sleep(0.001)

setAutoWaitTimeout(0.5)
buildingR = Region(507,278,137,126)
building = "vegetation-1.png"
menuR = Region(394,47,363,621)
destr = "destroy.png"
demoR = Region(588,574,173,57)
demo = "demolish-1.png"
empty = "emptyVegetation.png"
buildR = Region(640,609,69,29)
build = "build-1.png"
build2 = "build2-1.png"
speed ="speed-1.png"
sleep(1)
while True:
        Click(buildingR,building)
        Click(menuR,destr)
        Click(demoR,demo)
        Click(buildingR,empty)
        Click(menuR,build)
        Click(buildR,build2)
#        sleep(2)
        if menuR.exists(speed):
            sleep(1)
            Click(menuR,speed)