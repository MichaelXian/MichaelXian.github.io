#!/bin/bash
SIXTEENMEGABYTES="\x00"
for a in {0..24}
do
    SIXTEENMEGABYTES=$SIXTEENMEGABYTES$SIXTEENMEGABYTES
done

if  [ -z "$1" ]; then
    echo "Please input files to be wiped"
    exit 0
fi
START=$(date +%s)
echo "Warning: wiping files irrecoverably"
for FILE1 in "$@"
do
    SIZE=$(wc -c <"$FILE1")
    REPS=$(($SIZE/16777216+1)) #Calculate reps needed
    echo -e "\r$FILE1"
    i="0"
while [ $i -lt $SIZE ]
        do
            echo -ne $SIXTEENMEGABYTES | dd conv=notrunc bs=1 count=16777216 seek="$i" of="$FILE1" 2> /dev/null
            #write 16 MBs
            i="$(($i + 16777216))" #move pointer by 16 MBs
            echo -en "\r$(($i * 100 / $SIZE))%"
        done
#    rm "$FILE1"
done
    echo -en "\rDone     \n"
    END=$(date +%s)
    ELAPSED=$(($END-$START))
    echo "$ELAPSED second(s) passed"
