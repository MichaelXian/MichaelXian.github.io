
#!/bin/bash
if  [ -z "$1" ]; then
    echo "Please input files to be wiped"
    exit 0
fi
START=$(date +%s)
echo "Warning: wiping files irrecoverably"
for FILE1 in "$@"
do
    if [ ! -f $FILE1 ]; then
        continue
    fi
    SIZE=$(wc -c <"$FILE1")
    if [ "$SIZE" -eq 0 ]; then
        continue
    fi
    echo -e "\r$FILE1"
    for i in {0..5}
    do
        dd if=/dev/zero of="$FILE1" bs="$SIZE" count=1
    done
    
    rm "$FILE1"
done
    echo -en "\rDone     \n"
    END=$(date +%s)
    ELAPSED=$(($END-$START))
    echo "$ELAPSED second(s) passed"
