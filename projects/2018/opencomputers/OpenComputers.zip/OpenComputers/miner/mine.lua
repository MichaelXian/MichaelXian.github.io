local iterations = 1
local r = require("robot")
local comp = require("component")
local sides = require("sides")
local crafter = comp.crafting
local inv = comp.inventory_controller

local function wait(a)
    for i = 1,a do
        r.turnAround()
        r.turnAround()
    end
end

local function mineStack() 
    for i = 1,64 do
        r.place()
        r.swing()
    end
    r.select(2)
    r.transferTo(1)
    r.select(1)
end

local function newHammer()
    r.select(15)
    r.transferTo(6,1)
    r.transferTo(9,1)
    r.select(16)
    r.transferTo(7,1)
    r.transferTo(2,1)
    crafter.craft()
    r.select(1)
    inv.equip()
    r.dropDown()
end

while true do
    r.select(1)
    if (r.durability() < 0.02) then
            newHammer()
    end
    r.turnRight()
    while r.count(1) < 64 do
        r.suck(64 - r.count(1))
    end
    r.turnLeft()
    for i = 1,iterations do
        mineStack()
    end
    r.turnLeft()
    while (r.drop() == false) do
       wait(5)     
    end
    r.turnRight()
end


