r = require("robot")

function dealWithUntraversable()
    
end

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function wait(a)
    for i = 1,a do
        u()
        u()
    end
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
            dealWithUntraversable()
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
            dealWithUntraversable()
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
            dealWithUntraversable()
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
            dealWithUntraversable()
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end
