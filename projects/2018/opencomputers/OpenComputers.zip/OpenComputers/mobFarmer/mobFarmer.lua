r = require("robot")
t = require("component").tractor_beam
width = 16
length = 16
walkable = length - 1
function dealWithUntraversable()
    z = z + 1
    r.fill()
    r.drain()
    for i = 1,10 do
        t.suck()
    end
    --r.swing()
    while (t.suck() == true) do
    end
    if (z > 20) then
       r.swing() 
    end
end

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function wait(a)
    for i = 1,a do
        u()
        u()
    end
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
            dealWithUntraversable()
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
            dealWithUntraversable()
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
            dealWithUntraversable()
        end
    end
end

function walk(a)
    z = 0
    for i = 1,a do
        while (r.forward() == nil) do
            dealWithUntraversable()
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end

function rightEnd()
    right()
    walk(1)
    right()
end

function leftEnd()
    left()
    walk(1)
    left()
end

function cycle()
    walk(walkable)
    rightEnd()
    walk(walkable)
    leftEnd()
end

while true do
    curX = width - 2
    walk(1)
    while curX > 1 do
        curX = curX - 2
        print(curX)
        cycle()
    end
    walk(walkable)
    if (curX == 0) then
        u()
        walk(walkable)
    end
    right()
    walk(width - 2)
    left()
    walk(1)
    dropAll()
    u()
    wait(20)
end