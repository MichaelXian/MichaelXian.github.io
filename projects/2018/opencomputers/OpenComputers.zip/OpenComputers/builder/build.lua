r = require("robot")

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function wait(a)
    for i = 1,a do
        u()
        u()
    end
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end


function rightEnd()
    right()
    walkPlace(1)
    right()
end

function leftEnd()
    left()
    walkPlace(1)
    left()
end

function consolidate()
    for i = 2,16 do
        r.select(i)
        r.transferTo(1)
    end
    r.select(1)
end


function walkPlace(a)
    for i = 1,a do
        walk(1)
        r.placeDown()
        if (r.count(1) == 0) then
            consolidate()
        end
    end
end

for i = 1,13 do
    walkPlace(27)
    rightEnd()
    walkPlace(27)
    leftEnd()
end
walkPlace(27)
