r = require("robot")
function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end


function wait(a)
    for i = 1,a do
        u()
        u()
    end
end


function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
        end
    end
end

function useNext()
    r.use()
    fly(1)
    r.use()
    fall(1)
    right()
    walk(1)
    left()
end

function corner()
    fly(1)
    r.use()
    right()
    walk(3)
    left()
    walk(3)
    left()
    fall(1)
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end

while true do
    u()
    r.suck()
    u()
    r.drop()
    u()
    r.drop()
    u()
    right()
    fly(1)
    walk(3)
    left()
    walk(2)
    fall(2)
    left()
    useNext()
    useNext()
    r.use()
    corner()
    useNext()
    useNext()
    r.use()
    corner()
    useNext()
    useNext()
    r.use()
    fly(1)
    right()
    walk(2)
    left()
    walk(3)
    right()
    dropAll()
    left()
    walk(2)
    left()
    wait(10)
end
