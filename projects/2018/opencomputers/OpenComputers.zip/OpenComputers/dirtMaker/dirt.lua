r = require("robot")

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end

function wait(a)
    for i = 1,a do
        u()
        u()
    end
end

while true do
    walk(1)
    while (r.count(1) < 13)
        r.suck(13 - r.count(1))
    end
    back(1)
    for i = 1,13 do
        r.dropDown()
    end
    wait(20)
    r.useDown()
    r.dropUp()
end
