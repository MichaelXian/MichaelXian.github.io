r = require("robot")
comp = require("component")
crafter = comp.crafting
inv = comp.inventory_controller
rawSide = sides.left
oreSide = sides.front
blockSide = sides.right
max = 32

function dropAll()
    for int i = 1,16
        r.select(i)
        r.drop(rawSide)
    end
end

function consolidate()
    for int i = 2,16
        r.select(i)
        r.transferTo(1)
    end
end

function craft2()
    transferTo(2,16)
    transferTo(5,16)
    transferTo(6,16)
    return crafter.craft()
end

function craft3()
    for i = 2,9 do
        transferTo(i,9)
    end
    return crafter.craft()
end

function craftNamed(name)
    for i = 1,max do
        if (getStackInSlot(rawSide,i)["name"] == name) then
            suckFromSlot(rawside,i,64 - r.count())
            if (r.count() == 64) then
                if (craft2()) then
                    drop(oreSide)
                else 
                    consolidate()
                    drop(rawSide,1)
                    if (craft3())
                        drop(blockSide)
                    else
                        consolidate()
                        drop(blockSide())
                    end
            end
        end
    end
    dropAll()
end

while true do
    for i = 1,max do
        craftNamed(getStackInSlot(rawSide,i)["name"])
    end
end
