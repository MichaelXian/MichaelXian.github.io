r = require("robot")

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end
