r = require("robot")
comp = require("component")
sides = require("sides")
crafter = comp.crafting
inv = comp.inventory_controller
max = 27
forward = sides.forward
down = sides.down

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
        end
    end
end

function dropBlock()
    -- move to block pipe
    back(1)
    fall(2)
    while (r.dropDown() == nil) do
    end
    -- move back
    fly(2)
    walk(1)
    
end
function dropOre()
    -- move to ore pipe
    fall(2)
    while (r.dropDown() == nil) do
    end
    -- move back
    fly(2)
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end

function dropAllDown()
    for i = 1,16 do
        r.select(i)
        r.dropDown()
    end
    r.select(1)
end


function moveToBlocks()
    walk(1)
    left()
    walk(1)
    left()
end

function moveToOres()
    u()
    walk(1)
    left()
    walk(2)
    left() 
    walk(2)
    left()
    fly(1)
end

function moveToCharger()
    fall(1)
    left()
    walk(2)
    right()
    walk(3)
    right()
    walk(2)
    u()
end

function wait(a)
    for i = 1,a do
        u()
        u()
    end
end
function consolidate()
    for i = 2,16 do
        r.select(i)
        r.transferTo(1)
    end
    r.select(1)
end

function craft2()
    r.transferTo(2,16)
    r.transferTo(5,16)
    r.transferTo(6,16)
    for i = 1,16 do
        x = crafter.craft(1)
        r.select(3)
        r.transferTo(4)
    end
    consolidate()
    return x
    
end

function craft3()
    r.transferTo(2,7)
    r.transferTo(3,7)
    r.transferTo(5,7)
    r.transferTo(6,7)
    r.transferTo(7,7)
    r.transferTo(9,7)
    r.transferTo(10,7)
    r.transferTo(11,7)
    x = crafter.craft(7)
    consolidate()
    return x
end

function craftBlocks()
    for i = 1,max do
        inv.suckFromSlot(down,i, 63 - r.count(1))
        if (r.count(1) == 63) then
            craft3()
            r.drop()
        end
    end
    dropAllDown()
end

function craftNamed(name)
    for i = 1,max do
        if (inv.getStackInSlot(forward,i) ~= nil) then
            if (inv.getStackInSlot(forward,i)["name"] == name) then
                inv.suckFromSlot(forward,i,64 - r.count(1))
                if (r.count() == 64) then
                    if (craft2()) then
                        dropOre()
                    else 
                        consolidate()
                        r.drop(1)
                        if (craft3()) then
                            dropBlock()
                        else
                            consolidate()
                            dropBlock()
                        end
                    end
                end
            end
        end
    end
    dropAll()
end

function craftOres()
    for i = 1,max do
        if (inv.getStackInSlot(forward,i) ~= nil) then
            craftNamed(inv.getStackInSlot(forward,i)["name"])
        end
    end
end

while true do
    moveToBlocks()
    craftBlocks()
    moveToOres()
    craftOres()
    moveToCharger()
    wait(10)
end
