local robot = require("robot")
while true do
    robot.select(1)
    robot.turnRight()
    robot.suck()
    robot.turnAround()
    
    for i = 0,63 do
        robot.place()
        robot.swing()
    end
    roblot.place()
    robot.select(2)
    robot.swing()
    for i = 0,63 do
        robot.place()
        robot.swing()
    end
    robot.place()
    robot.select(3)
    robot.swing()
    for i = 0,63 do
        robot.place()
        robot.swing()
    end
    robot.place()
    robot.select(4)
    robot.swing()
    
    robot.turnRight()
    
    robot.drop()
end

local robot = require("robot")
local function pS()
    robot.place()
    robot.swing()
end
local function PS(a) 
    robot.place()
    robot.select(a)
    robot.swing()
end
while true do
    robot.select(1)
    robot.turnRight()
    robot.suck()
    robot.turnAround()
    
    for i = 0,63 do
        pS()
    end
    PS(2)
    for i = 0,63 do
        pS()
    end
    PS(3)
    for i = 0,63 do
        pS()
    end
    PS(4)
    
    robot.turnRight()
    
    robot.drop()
end



toSand

local robot = require("robot")
local function pS()
    robot.place()
    robot.swing()
end
local function PS(a) 
    robot.place()
    robot.select(a)
    robot.swing()
end
while true do
    robot.select(1)
    robot.turnRight()
    while robot.count(1) < 64 do
    robot.suck()
    end
    robot.select(2)
    robot.drop()
    robot.turnAround()
    robot.select(1)
    
    for i = 0,63 do
        pS()
    end
    PS(2)
    for i = 0,63 do
        pS()
    end
    PS(3) 
    robot.turnRight()
    robot.drop()
end



toGravel
local robot = require("robot")
local function pS()
    robot.place()
    robot.swing()
end
local function PS(a) 
    robot.place()
    robot.select(a)
    robot.swing()
end
while true do
    robot.select(1)
    robot.turnRight()
    while robot.count(1) < 64 do
    robot.suck()
    end
    robot.select(2)
    robot.drop()
    robot.turnAround()
    robot.select(1)
    
    for i = 0,63 do
        pS()
    end
    PS(2)
    robot.turnRight()
    robot.drop()
end
