r = require("robot")
comp = require("component")
crafter = comp.crafting
inv = comp.inventory_controller
rawSide = sides.left
oreSide = sides.front
blockSide=sides.right

function dropAll()
    for int i = 1,16
        r.select(i)
        r.drop(rawSide)
    end
end

function craft2()
    transferTo(2,16)
    transferTo(5,16)
    transferTo(6,16)
    crafter.craft()
end

function craft3()
    for i = 2,9 do
        transferTo(i,9)
    end
    crafter.craft()
end

function craft2(name)
    for i = 1,32 do
        if (getStackInSlot(rawSide,i)["name"] == name) then
            suckFromSlot(rawside,i,64 - r.count())
            if (r.count() == 64) then
                craft2()
                drop(oreSide)
            end
        end
    end
    dropAll()
end

function craft3(name)
    for i = 1,32 do
        if (getStackInSlot(rawSide,i)["name"] == name) then
            suckFromSlot(rawside,i,64 - r.count())
            if (r.count() == 64) then
                craft3()
                drop(blockSide)
            end
        end
    end
    dropAll()
end

