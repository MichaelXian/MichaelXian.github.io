r = require("robot")
comp = require("component")
sides = require("sides")
inv = comp.inventory_controller
crafter = comp.crafting
glowstone = "minecraft:glowstone"
coal = "minecraft:coal_block"
front = sides.front
length = 7
ore = 0
fuel = 1
product = 2
function dealWithUntraversable()
    
end

function left()
    r.turnLeft()
end
function right()
    r.turnRight()
end
function u()
    r.turnAround()
end
function wait(a)
    for i = 1,a do
        u()
        u()
    end
end
function fall(a)
    for i = 1,a do
        while (r.down() == nil) do
            dealWithUntraversable()
        end
    end
end

function fly(a)
    for i = 1,a do
        while (r.up() == nil) do
            dealWithUntraversable()
        end
    end
end

function back(a)
    for i = 1,a do
        while (r.back() == nil) do
            dealWithUntraversable()
        end
    end
end

function walk(a)
    for i = 1,a do
        while (r.forward() == nil) do
            dealWithUntraversable()
        end
    end
end

function dropAll()
    for i = 1,16 do
        r.select(i)
        r.drop()
    end
    r.select(1)
end

function consolidate()
    for i = 2,16 do
        r.select(i)
        r.transferTo(1)
    end
    r.select(1)
end

function chargerToBlocks()
    left()
    walk(1)
    left()
    dropAll()
end

function blocksToBlockDrop()
    right()
    fly(1)
    walk(4)
    left()
    walk(1)
end

function blockDropToCharger()
    u()
    fly(1)
    walk(5)
    left()
    walk(1)
    fall(1)
end

function chargerToOreDrop()
    right()
    fly(1)
    walk(4)
    right()
    walk(1)
    u()
end

function oreDropToCharger()
    fly(1)
    left()
    walk(4)
    fall(1)
    right()
end

function pickUpExcept(name, max)
    max = max or 99999
    for i = 1,32 do
        if max <= 0 then
            break
        end
        stack = inv.getStackInSlot(front,i)
        if stack ~= nil then
            if stack["name"] ~= name then
                inv.suckFromSlot(front, max)
                max = max - stack["size"]
            end
        end
    end
end

function pickUpOnly(name, max)
    max = max or 99999
    for i = 1,32 do
        if max <= 0 then
            break
        end
        stack = inv.getStackInSlot(front,i)
        if stack ~= nil then
            if stack["name"] == name then
                inv.suckFromSlot(front, max)
                max = max - stack["size"]
            end
        end
    end
end

function craft3()
    r.transferTo(2,7)
    r.transferTo(3,7)
    r.transferTo(5,7)
    r.transferTo(6,7)
    r.transferTo(7,7)
    r.transferTo(9,7)
    r.transferTo(10,7)
    r.transferTo(11,7)
    x = crafter.craft(7)
    consolidate()
    return x
end

function craftBlocks()
    for i = 1,32 do
        stack = inv.getStackInSlot(front,i)
        if stack ~= nil then
            craftBlock(stack["name"])
        end
    end
end

function craftBlock(name)
    for i = 1,32 do
        stack = inv.getStackInSlot(front,i)
        if stack ~= nil then
            if stack["name"] == name then
                inv.suckFromSlot(front,i, 63 - r.count(1))
                if (r.count(1) == 63) then
                    craft3()
                    r.drop()
                end
            end
        end
    end
    u()
    dropAll()
    u()
end



function dropOffBlocks()
    chargerToBlocks()
    pickUpExcept(coal)
    blocksToBlockDrop()
    blockDropToCharger()
end

function dropCoal()

end

function fillRowCoal()
    for i = 1,length do
        walk(1)
        left()
        r.drop()
        consolidate()
        right()
    end
    u()
    walk(length)
    u()
    
end

function fillCoal()
    chargerToBlocks()
    pickUpOnly(coal,113)
    u()
    fillRowCoal()
    left()
    walk(1)
    left()
    fillRow()
end

function dropExtraCoal()
    chargerToBlocks()
    blocksToBlockDrop()
    u()
    dropAll()
    craftBlocks()
    blockDropToCharger()
end

function fillRowOres()
    for i = 1,length do
        walk(1)
        r.dropDown()
        consolidate()
    end
    u()
    walk(length)
    u()
end

function putOres()
    u()
    pickUpExcept(glowstone)
    left()
    fly(1)
    walk(1)
    left()
    fillRowOres()
    left()
    walk(3)
    right()
    fillRowOres()
    u()
    walk(2)
    fall(1)
    right()
    dropAll()
    u()
end

function dropOffGlowstone()
    u()
    pickUpOnly(glowstone)
    u()
    chargerToBlockDrop()
    dropAll()
    blockDropToCharger()
end

function suckRowOres()
    for i = 1,length - 1 do
        r.suckUp()
        walk(1)
    end
    r.suckUp()
    u()
    walk(length - 1)
    u()
end

function pickUpOres()
    walk(1)
    fall(1)
    right()
    walk(1)
    left()
    suckRowOres()
    left()
    walk(3)
    right()
    suckRowOres()
    right()
    walk(2)
    right()
    fly(1)
    walk(1)
    u()
end



function dropOffOres()
    chargerToOreDrop()
    dropAll()
    craftBlocks()
    oreDropToCharger()
end

while true do
    dropOffBlocks()
    fillCoal()
    dropExtraCoal()
    putOres()
    dropOffGlowstone()
    pickUpOres()
    dropOffOres()
end
