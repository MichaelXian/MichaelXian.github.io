#!/bin/bash
sudo lsof -i :$1 | grep LISTEN
