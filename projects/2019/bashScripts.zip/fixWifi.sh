#!/bin/bash
sudo ip link set wlp2s0 down
sudo rfkill unblock all 
