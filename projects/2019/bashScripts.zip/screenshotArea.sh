#!/bin/bash
sleep 0.1
gnome-screenshot -a -f $HOME/Documents/Screenshots/temp/$(date +%Y%m%d%H%M%S).png
