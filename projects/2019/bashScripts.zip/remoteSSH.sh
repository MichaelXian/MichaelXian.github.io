#!/bin/bash
ssh $REMOTE
